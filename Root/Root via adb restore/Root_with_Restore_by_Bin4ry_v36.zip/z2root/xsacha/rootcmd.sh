if [ ! -f /data/local/tmp/TA.img ]; then
  echo "Backing up TA.."
  ls -alF /dev/block/platform/msm_sdcc.1/by-name/TA
  dd if=/dev/block/platform/msm_sdcc.1/by-name/TA of=/data/local/tmp/TA.img
  echo "Created /data/local/tmp/TA.img -- Checking MD5.."
  md5 /dev/block/platform/msm_sdcc.1/by-name/TA /data/local/tmp/TA.img
  chmod 777 /data/local/tmp/TA.img
fi

/data/local/tmp/busybox sh /data/local/tmp/rickroll.sh

echo "Deploying su"
mount -o remount,rw /system
/system/bin/cp /data/local/tmp/su /system/xbin/su
/system/bin/cp /data/local/tmp/su /system/xbin/daemonsu
/system/bin/chown 0.0 /system/xbin/su
/system/bin/chown 0.0 /system/xbin/daemonsu
/system/bin/chmod 6755 /system/xbin/su
/system/bin/chmod 6755 /system/xbin/daemonsu
/system/bin/sync
/system/bin/mount -o remount,ro /system