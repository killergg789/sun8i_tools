echo "Disabling sony_ric"
# TODO: Read from memory to find ric_enabled location
echo 0 > /proc/sys/kernel/kptr_restrict
SONY_RIC_ENABLED=`cat /proc/kallsyms | grep " sony_ric_enabled" | /data/local/tmp/busybox awk '{ print $1 }'`
RIC_ENABLED=`echo $(( 12 + 0x$SONY_RIC_ENABLED ))`
KILL_ADDRESS=$((0x`dd if=/dev/kmem skip=$RIC_ENABLED bs=1 count=4 | /data/local/tmp/busybox hexdump | /data/local/tmp/busybox awk '{ print $3$2 }'`))
dd if=/dev/zero of=/dev/kmem bs=1 count=4 seek=$KILL_ADDRESS