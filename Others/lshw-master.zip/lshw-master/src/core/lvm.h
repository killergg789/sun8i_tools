#ifndef _LVM_H_
#define _LVM_H_

#include "hw.h"
#include "blockio.h"

bool scan_lvm(hwNode & n, source & s);
#endif
