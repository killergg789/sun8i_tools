#ifndef _JEDEC_H_
#define _JEDEC_H_

#include <string>

std::string jedec_resolve(const std::string &);

#endif
