#ifndef _PARISC_H_
#define _PARISC_H_

#include "hw.h"

bool scan_parisc(hwNode & n);
#endif
