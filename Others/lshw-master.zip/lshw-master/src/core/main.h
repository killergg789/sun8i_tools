#ifndef _MAIN_H_
#define _MAIN_H_

#include "hw.h"

bool scan_system(hwNode & system);
#endif
