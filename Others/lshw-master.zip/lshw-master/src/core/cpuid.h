#ifndef _CPUID_H_
#define _CPUID_H_

#include "hw.h"

bool scan_cpuid(hwNode & n);
#endif
