#ifndef _SMP_H_
#define _SMP_H_

#include "hw.h"

bool scan_smp(hwNode & n);
#endif
