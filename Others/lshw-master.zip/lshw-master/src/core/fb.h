#ifndef _FB_H_
#define _FB_H_

#include "hw.h"

bool scan_fb(hwNode & n);
#endif
