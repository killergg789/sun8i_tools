#ifndef _MEM_H_
#define _MEM_H_

#include "hw.h"

bool scan_memory(hwNode & n);
#endif
