#ifndef _VIRTIO_H_
#define _VIRTIO_H_

#include "hw.h"

bool scan_virtio(hwNode &);

#endif
