#ifndef _IDERAID_H_
#define _IDERAID_H_

#include "hw.h"

bool scan_ideraid(hwNode & n);
#endif
